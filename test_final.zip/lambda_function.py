import hashlib
import hmac
import json
import os
import requests
import re
from jira import JIRA
import boto3
from requests.auth import HTTPBasicAuth
from PIL import Image
from PIL.Image import core as _imaging


def verify_github_webhook(event, context):
    # Replace 'YOUR_GITHUB_SECRET' with your actual GitHub webhook secret
    github_secret = os.environ.get('github_secret')

    if github_secret is None:
        return {
            'statusCode': 500,
            'body': 'GitHub secret is not configured.'
        }

    # Get the request headers and payload
    
    print(json.dumps(event, indent=2))  # Print the entire event for inspection
    
    # Access individual headers from the 'headers' object
    headers = event.get('headers', {})
    print("Headers:", headers)
    
    body = event.get('body', {})
    print("Body:", body)

    # Check if the 'x-Hub-Signature' header is present
    if 'X-Hub-Signature' not in headers:
        return {
            'statusCode': 400,
            'body': 'X-Hub-Signature header is missing.'
        }

    # Retrieve the signature from the headers
    provided_signature = headers['X-Hub-Signature']

    # Calculate the expected signature using the secret and payload
    expected_signature = 'sha1=' + hmac.new(
        github_secret.encode('utf-8'),
        body.encode('utf-8'),  # Use 'body' instead of 'payload'
        hashlib.sha1
    ).hexdigest()

    # Compare the provided signature with the expected signature
    if not hmac.compare_digest(provided_signature, expected_signature):
        return {
            'statusCode': 403,
            'body': 'Signature verification failed.'
        }

    return {
        'statusCode': 200,
        'body': 'GitHub webhook connection verified.'
    }

def create_jira_ticket(event, context):
    # Jira API URL
    url = os.environ.get('jira_api_endpoint')

    # API token and user email from environment variables
    api_token = os.environ.get('jira_api_token')
    user_email = os.environ.get('jira_user')

    auth = HTTPBasicAuth(user_email, api_token)

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json"
    }

    # Parse the GitHub webhook payload JSON
    github_payload = json.loads(event.get('body', '{}'))  # Parse 'body' as JSON

    # Extract relevant information from the GitHub payload
    repo_name = github_payload.get('repository', {}).get('name')
    created_at = github_payload.get('repository', {}).get('created_at')
    issue_url = github_payload.get('repository', {}).get('html_url')
    action = github_payload.get('action', {})

    # Create the Jira ticket payload
    payload = json.dumps({
        "fields": {
            "description": {
                "content": [
                    {
                        "content": [
                            {
                                "text": f"GitHub Issue URL: {issue_url}, {action} at {created_at}",
                                "type": "text"
                            }
                        ],
                        "type": "paragraph"
                    }
                ],
                "type": "doc",
                "version": 1
            },
            "project": {
                "key": "JR"  # Adjust the Jira project key as needed
            },
            "issuetype": {
                "name": "Task"
            },
            "summary": f"GitHub Issue in {repo_name}: something is {action}",
        },
        "update": {}
    })

    response = requests.post(url, data=payload, headers=headers, auth=auth)

    return {
        'statusCode': 200,
        'body': json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": "))
    }




def lambda_handler(event, context):
    # Call both functions
    result1 = verify_github_webhook(event, context)
    result2 = create_jira_ticket(event, context)

    # You can choose how to handle the results or combine them as needed
    combined_result = {
        'verify_github_webhook_result': result1,
        'create_jira_ticket_result': result2
    }

    return {
        'statusCode': 200,
        'body': json.dumps(combined_result),
        'headers': {
            'Content-Type': 'application/json'
         }
    }

